// controllers/userController.js (snippet: ONLY registerUser shown updated)

const asyncHandler = require('express-async-handler');
const bcrypt = require('bcryptjs');
const UserService = require('../services/userService');
const generateToken = require('../utils/generateToken');
const User = require('../models/User');
const OTPVerification = require('../models/OTPVerification');
const { generateOTP, sendOTP, sendWelcomeSMS } = require('../services/twilioService');
const {
  sendSuccess,
  sendError,
  sendValidationError,
  sendNotFound,
  sendUnauthorized,
} = require('../utils/responseHelper');

const Checkr = require('../services/checkrService');

// -------------------- REGISTER (UPDATED) --------------------
const registerUser = asyncHandler(async (req, res) => {
  try {
    // 1) Create user via your service
    const user = await UserService.register(req.body, req.files);

    // 2) Auto-invite to Checkr if role === driver and email is present
    if (user.role === 'driver' && user.email) {
      console.log(user,"useruseruseruseruseruseruser")
      // Ensure vehicle types are selected for drivers
      if (!user.driver || !user.driver.vehicleTypes || user.driver.vehicleTypes.length === 0) {
        return sendError(res, 400, 'At least one vehicle type must be selected for drivers');
      }

      try {
        // Get full doc (UserService.formatUser returns minimal fields)
        const fullUser = await User.findById(user._id);

        // Create (or reuse) candidate
        let candidateId = fullUser.driver?.checkr?.candidateId;
        if (!candidateId) {
          const candidate = await Checkr.createCandidate(fullUser);
          candidateId = candidate.id;
          fullUser.driver.checkr = {
            ...(fullUser.driver?.checkr || {}),
            candidateId,
          };
        }
        console.log(candidateId,"candidateIdcandidateIdcandidateId")
        // Send invitation (Hosted flow)
        const inv = await Checkr.createInvitation({
          candidateId,
          pkg: process.env.CHECKR_DEFAULT_PACKAGE,
          nodeId: process.env.CHECKR_NODE_ID,
          work: null,
        });

        fullUser.driver.checkr = {
          ...(fullUser.driver?.checkr || {}),
          invitationId: inv.id,
          reportId: inv.report_id || fullUser.driver?.checkr?.reportId || null,
          status: 'invited',
          lastEvent: 'invitation.created',
          lastEventAt: new Date(),
        };

        // Convenience dashboard link (candidate now; report later if present)
        const DASH =
          process.env.CHECKR_DASHBOARD_BASE || 'https://dashboard.checkr.com';
        fullUser.driver.checkr.dashboardUrl = inv.report_id
          ? `${DASH}/reports/${inv.report_id}`
          : `${DASH}/candidates/${candidateId}`;

        await fullUser.save();
      } catch (e) {
        // Don’t fail the registration if Checkr invite fails — just log
        // eslint-disable-next-line no-console
        console.error(
          'Checkr auto-invite failed:',
          e?.response?.data || e.message
        );
      }
    }

    return sendSuccess(res, 201, 'User registered successfully', user);
  } catch (error) {
    // eslint-disable-next-line no-console
    console.error('Registration Error:', error);
    return sendError(res, 500, error.message || 'Registration failed');
  }
});


// -------------------- (your existing functions stay unchanged) --------------------

// Login (unchanged)
const loginUser = asyncHandler(async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return sendValidationError(res, 'Email and password are required');
    }

    const user = await UserService.findByEmail(email);
    if (!user) {
      return sendUnauthorized(res, 'Invalid credentials');
    }

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return sendUnauthorized(res, 'Invalid credentials');
    }

    const token = generateToken(user._id, user.role);
    const userData = UserService.formatUser(user);

    return sendSuccess(res, 200, 'Login successful', { token, user: userData });
  } catch (error) {
    console.error('Login Error:', error);
    return sendError(res, 500, error.message || 'Login failed');
  }
});

// Update driver profile (unchanged)
const updateDriverProfile = asyncHandler(async (req, res) => {
  try {
    const userId = req.user.id;
    const { ssn, vehicleTypes } = req.body;
    const licenseImage = req.files?.licenseImage?.[0];
    const vehicleImage = req.files?.vehicleImage?.[0];
    const updateData = {};

    if (ssn) updateData['driver.ssn'] = ssn;

    if (vehicleTypes) {
      const mongoose = require('mongoose');
      updateData['driver.vehicleTypes'] = Array.isArray(vehicleTypes)
        ? vehicleTypes.map((v) => new mongoose.Types.ObjectId(v))
        : [new mongoose.Types.ObjectId(vehicleTypes)];
    }

    if (licenseImage) {
      updateData['driver.licenseImage'] = `/uploads/${licenseImage.filename}`;
    }

    if (vehicleImage) {
      updateData['driver.vehicleImage'] = `/uploads/${vehicleImage.filename}`;
    }

    const user = await User.findByIdAndUpdate(
      userId,
      { $set: updateData },
      { new: true }
    );

    if (!user) return sendNotFound(res, 'User not found');

    return sendSuccess(res, 200, 'Driver profile updated successfully', user);
  } catch (error) {
    console.error('Update Profile Error:', error);
    return sendError(res, 500, error.message || 'Profile update failed');
  }
});

// Get profile (unchanged)
const getProfile = asyncHandler(async (req, res) => {
  try {
    const user = await User.findById(req.user.id).select('-password');
    if (!user) return sendNotFound(res, 'User not found');
    return sendSuccess(res, 200, 'Profile retrieved successfully', user);
  } catch (error) {
    console.error('Get Profile Error:', error);
    return sendError(res, 500, error.message || 'Failed to retrieve profile');
  }
});

// -------------------- PHONE-BASED AUTHENTICATION --------------------

// Send OTP for signup/login
const sendOTPForAuth = asyncHandler(async (req, res) => {
  try {
    const { phone } = req.body;

    if (!phone) {
      return sendValidationError(res, 'Phone number is required');
    }

    // Generate 6-digit OTP
    const otpCode = generateOTP();
    
    // Set expiration time (5 minutes from now)
    const expiresAt = new Date(Date.now() + 5 * 60 * 1000);

    // Delete any existing OTP for this phone number
    await OTPVerification.deleteMany({ phone });

    // Save new OTP
    const otpVerification = new OTPVerification({
      phone,
      code: otpCode,
      expiresAt
    });

    await otpVerification.save();

    // Send OTP via SMS
    await sendOTP(phone, otpCode);

    return sendSuccess(res, 200, 'OTP sent successfully', {
      phone,
      expiresIn: '5 minutes'
    });
  } catch (error) {
    console.error('Send OTP Error:', error);
    return sendError(res, 500, error.message || 'Failed to send OTP');
  }
});

// Verify OTP and complete signup/login
const verifyOTPAndAuth = asyncHandler(async (req, res) => {
  try {
    const { phone, code } = req.body;

    if (!phone || !code) {
      return sendValidationError(res, 'Phone number and OTP code are required');
    }

    // Find the OTP verification record
    const otpRecord = await OTPVerification.findOne({
      phone,
      code,
      verified: false,
      expiresAt: { $gt: new Date() }
    });

    if (!otpRecord) {
      return sendUnauthorized(res, 'Invalid or expired OTP');
    }

    // Check attempt limit (max 3 attempts)
    if (otpRecord.attempts >= 3) {
      await OTPVerification.deleteOne({ _id: otpRecord._id });
      return sendUnauthorized(res, 'Too many failed attempts. Please request a new OTP.');
    }

    // Increment attempts
    otpRecord.attempts += 1;
    await otpRecord.save();

    // Check if user exists
    let user = await UserService.findByPhone(phone);
    let isNewUser = false;

    if (!user) {
      // Create new user
      isNewUser = true;
      const newUserData = {
        phone,
        role: 'customer', // Default role
        isPhoneVerified: true
      };

      user = await UserService.register(newUserData);
      
      // Send welcome SMS for new users
      try {
        await sendWelcomeSMS(phone, user.name || 'User');
      } catch (welcomeError) {
        console.error('Welcome SMS failed:', welcomeError);
        // Don't fail the registration for welcome SMS error
      }
    } else {
      // Update existing user's phone verification status
      await UserService.updatePhoneVerification(phone, true);
    }

    // Mark OTP as verified
    otpRecord.verified = true;
    await otpRecord.save();

    // Generate JWT token
    const token = generateToken(user._id, user.role);
    const userData = UserService.formatUser(user);

    return sendSuccess(res, 200, isNewUser ? 'Account created and verified successfully' : 'Login successful', {
      token,
      user: userData,
      isNewUser
    });
  } catch (error) {
    console.error('Verify OTP Error:', error);
    return sendError(res, 500, error.message || 'OTP verification failed');
  }
});

// Add email to existing account (optional)
const addEmailToAccount = asyncHandler(async (req, res) => {
  try {
    const { email } = req.body;
    const userId = req.user.id;

    if (!email) {
      return sendValidationError(res, 'Email is required');
    }

    // Check if email already exists
    const existingUser = await User.findOne({ email, _id: { $ne: userId } });
    if (existingUser) {
      return sendError(res, 400, 'Email already exists');
    }

    // Update user with email
    const user = await User.findByIdAndUpdate(
      userId,
      { email },
      { new: true }
    );

    if (!user) {
      return sendNotFound(res, 'User not found');
    }

    const userData = UserService.formatUser(user);
    return sendSuccess(res, 200, 'Email added successfully', userData);
  } catch (error) {
    console.error('Add Email Error:', error);
    return sendError(res, 500, error.message || 'Failed to add email');
  }
});

// Phone-based login (alternative to OTP verification)
const loginWithPhone = asyncHandler(async (req, res) => {
  try {
    const { phone } = req.body;

    if (!phone) {
      return sendValidationError(res, 'Phone number is required');
    }

    const user = await UserService.findByPhone(phone);
    // if (!user) {
    //   return sendUnauthorized(res, 'User not found');
    // }

    // if (!user.isPhoneVerified) {
    //   return sendUnauthorized(res, 'Phone number not verified');
    // }

    // Generate JWT token
    const token = generateToken(user._id, user.role);
    const userData = UserService.formatUser(user);

    return sendSuccess(res, 200, 'Login successful', {
      token,
      user: userData
    });
  } catch (error) {
    console.error('Phone Login Error:', error);
    return sendError(res, 500, error.message || 'Login failed');
  }
});

module.exports = {
  registerUser,
  loginUser,
  updateDriverProfile,
  getProfile,
  sendOTPForAuth,
  verifyOTPAndAuth,
  addEmailToAccount,
  loginWithPhone,
};
